<?php
$servername = "db.example.com";
$username = "db_user";
$password = "db_pass";
$dbusers = "your_db"; 
// Create connection

//echo "Connected successfully";
?>
